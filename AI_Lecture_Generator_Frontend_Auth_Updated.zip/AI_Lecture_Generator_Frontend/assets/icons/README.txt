Icons are represented with simple Unicode symbols to keep the project dependency-free. A single icon library can be added later if desired.
