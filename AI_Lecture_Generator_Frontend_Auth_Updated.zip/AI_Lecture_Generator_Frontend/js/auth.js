// Authentication for the frontend demo project.
// A real application must authenticate and authorize users on a secure backend.
const DEMO_MANAGER={id:"manager-1",name:"System Manager",email:"manager@example.com",password:"manager123",role:"manager"};
function getTeachersForAuth(){const list=JSON.parse(localStorage.getItem("teachers")||JSON.stringify([
{id:1,name:"John Smith",email:"john@example.com",department:"Computer Science",username:"Johnsmith",password:"teacher123",status:"Active"},
{id:2,name:"Ahmed Ali",email:"ahmed@example.com",department:"Information Technology",username:"Ahmedali",password:"teacher123",status:"Active"},
{id:3,name:"Sara Hassan",email:"sara@example.com",department:"Information Technology",username:"Sarahassan",password:"teacher123",status:"Active"}
]));return list.map(t=>({...t,password:t.password||"teacher123"}));}
function saveCurrentUser(user){localStorage.setItem("currentUser",JSON.stringify({id:user.id,name:user.name,email:user.email,role:user.role}));localStorage.setItem("role",user.role);}
function getCurrentUser(){try{return JSON.parse(localStorage.getItem("currentUser"));}catch{return null;}}
function loginUser(email,password,role){const e=email.trim().toLowerCase();if(role==="manager"&&e===DEMO_MANAGER.email&&password===DEMO_MANAGER.password){saveCurrentUser(DEMO_MANAGER);return DEMO_MANAGER;}if(role==="teacher"){const t=getTeachersForAuth().find(x=>x.status==="Active"&&x.email.toLowerCase()===e&&x.password===password);if(t){const user={...t,role:"teacher"};saveCurrentUser(user);return user;}}return null;}
document.getElementById("loginForm")?.addEventListener("submit",function(e){e.preventDefault();const email=document.getElementById("loginEmail").value,password=document.getElementById("loginPassword").value,role=document.getElementById("loginRole").value,error=document.getElementById("loginError"),user=loginUser(email,password,role);if(!user){error.textContent="Invalid email, password, or account role.";return;}window.location.href=user.role==="manager"?"pages/manager-dashboard.html":"pages/teacher-home.html";});
if(document.getElementById("loginForm")){const user=getCurrentUser();if(user)window.location.href=user.role==="manager"?"pages/manager-dashboard.html":"pages/teacher-home.html";}
