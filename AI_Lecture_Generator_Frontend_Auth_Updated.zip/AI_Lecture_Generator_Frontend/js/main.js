// Shared dummy data. In a real application these arrays would come from an API/database.
const teachers=JSON.parse(localStorage.getItem("teachers")||JSON.stringify([
{id:1,name:"John Smith",email:"john@example.com",department:"Computer Science",username:"Johnsmith",password:"teacher123",status:"Active"},
{id:2,name:"Ahmed Ali",email:"ahmed@example.com",department:"Information Technology",username:"Ahmedali",password:"teacher123",status:"Active"},
{id:3,name:"Sara Hassan",email:"sara@example.com",department:"Information Technology",username:"Sarahassan",password:"teacher123",status:"Active"}
]));
const references=JSON.parse(localStorage.getItem("references")||JSON.stringify([{id:1,name:"Artificial Intelligence",author:"John Smith",date:"2025",type:"PDF"},{id:2,name:"Machine Learning",author:"Sara Hassan",date:"2024",type:"DOCX"},{id:3,name:"Data Ethics",author:"Ahmed Ali",date:"2023",type:"PPTX"}]));
const summaries=JSON.parse(localStorage.getItem("summaries")||JSON.stringify([{id:1,name:"AI Fundamentals",reference:"AI Fundamentals.pdf",format:"Word",date:"20 Sep 2026",length:"Medium"},{id:2,name:"Machine Learning Basics",reference:"ML Basics.pdf",format:"PowerPoint",date:"18 Sep 2026",length:"Long"},{id:3,name:"Data Ethics",reference:"Data Ethics.pdf",format:"Word",date:"15 Sep 2026",length:"Short"}]));
function getCurrentUser(){try{return JSON.parse(localStorage.getItem("currentUser"));}catch{return null;}}
function requireRole(allowedRoles){const user=getCurrentUser(),roles=Array.isArray(allowedRoles)?allowedRoles:[allowedRoles];if(!user||!roles.includes(user.role)){window.location.href="../index.html";return null;}return user;}
function saveData(){localStorage.setItem("teachers",JSON.stringify(teachers));localStorage.setItem("references",JSON.stringify(references));localStorage.setItem("summaries",JSON.stringify(summaries));}
function showToast(message){const t=document.getElementById("toast");if(!t)return;t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600);}
function setupSidebar(){const sidebar=document.querySelector(".sidebar"),menu=document.querySelector(".mobile-menu");if(menu&&sidebar)menu.addEventListener("click",()=>sidebar.classList.toggle("open"));}
function logout(){localStorage.removeItem("role");localStorage.removeItem("currentUser");window.location.href="../index.html";}
function go(page){window.location.href=page;}
document.addEventListener("DOMContentLoaded",()=>{const page=window.location.pathname.toLowerCase().split("/").pop();const managerPages=["manager-dashboard.html","teachers.html","add-teacher.html","edit-teacher.html","delete-teacher.html"],teacherPages=["teacher-home.html","generate-summary.html","upload-reference.html","previous-summaries.html","references.html"];if(managerPages.includes(page))requireRole("manager");if(teacherPages.includes(page))requireRole("teacher");setupSidebar();});
